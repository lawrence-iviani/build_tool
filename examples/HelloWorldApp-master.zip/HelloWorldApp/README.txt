This is a demo portable Hello World application.
